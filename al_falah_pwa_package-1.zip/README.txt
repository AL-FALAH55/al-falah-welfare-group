AL-FALAH ASSOCIATION WELFARE GROUP — PWA starter package

Contents:
- index.html: mobile app demo
- manifest.webmanifest: installable app metadata
- sw.js: offline cache support
- icons/: launcher icons

Important:
This is a starter PWA package, not an APK. To install it as a PWA, upload these files to a secure HTTPS host (for example, GitHub Pages). Then open the hosted site in Chrome on Android and use Menu > Install app or Add to Home screen.
Member form entries are stored only in the same browser/device using localStorage; there is no cloud database or admin panel yet.
